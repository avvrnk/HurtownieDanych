CREATE TABLE Rezerwacja (
    Miasto varchar(30) not null, 
    DataWyjazdu date not null, 
    Cena decimal(10,2) not null, 
    LiczbaOsob integer not null, 
);

 